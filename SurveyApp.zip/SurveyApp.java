import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax. swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

public class SurveyApp extends JFrame implements ActionListener {
	JFrame f = new JFrame();
	JLabel q = new JLabel("Pytesori");
	JLabel q1 = new JLabel("1.Me qfar note e vleresoni pastertine?");
	JLabel q2 = new JLabel("2.Me qfar note e vleresoni ushqimin?");
	JLabel q3 = new JLabel("3.Me qfar note e vleresoni inventarin?");
	JButton b1 = new JButton("Finish");
	JButton b2 = new JButton("Exit");
	JRadioButton a1 = new JRadioButton("1");
		JRadioButton a11 = new JRadioButton("2");
			JRadioButton a12 = new JRadioButton("3");
				JRadioButton a13 = new JRadioButton("4");
				JRadioButton a14 = new JRadioButton("5");
	
	JRadioButton a2 = new JRadioButton("1");
	JRadioButton a21 = new JRadioButton("2");
			JRadioButton a22 = new JRadioButton("3");
				JRadioButton a23 = new JRadioButton("4");
				JRadioButton a24 = new JRadioButton("5");
	
	JRadioButton a3 = new JRadioButton("1");
	JRadioButton a31 = new JRadioButton("2");
			JRadioButton a32 = new JRadioButton("3");
				JRadioButton a33 = new JRadioButton("4");
				JRadioButton a34 = new JRadioButton("5");
	
	
	JLabel a4 = new JLabel("Koment:");
	JTextField v1 = new JTextField("");
	
	JLabel r1 = new JLabel("Koment2:");
	JTextField r12 = new JTextField("");
	
	
	JLabel q4 = new JLabel("4.Nota per sherbimin:");
	JLabel q5 = new JLabel("5.Nota per mikepritjen:");
	JLabel q6 = new JLabel("6.Nota per ndriqimin:");
	JLabel v2 = new JLabel("Vleresimi i stafit:");
	
	 JRadioButton a5 = new JRadioButton("1");
		JRadioButton a51 = new JRadioButton("2");
			JRadioButton a52 = new JRadioButton("3");
				JRadioButton a53 = new JRadioButton("4");
				JRadioButton a54 = new JRadioButton("5");
				
	JRadioButton a6 = new JRadioButton("1");
		JRadioButton a61 = new JRadioButton("2");
			JRadioButton a62 = new JRadioButton("3");
				JRadioButton a63 = new JRadioButton("4");
				JRadioButton a64 = new JRadioButton("5");
				
	JRadioButton a7 = new JRadioButton("1");
		JRadioButton a71 = new JRadioButton("2");
			JRadioButton a72 = new JRadioButton("3");
				JRadioButton a73 = new JRadioButton("4");
				JRadioButton a74 = new JRadioButton("5");
				

public SurveyApp(){
	setVisible(true);
	setSize(1200, 1200);
	setLocationRelativeTo(null);
	//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setTitle("Grinesa");
	setLayout(null);
	setResizable(false);
	q.setBounds(10, 10, 200, 30);
	q1.setBounds(10, 40, 300, 40);
	a1.setBounds(420, 40, 50,30);
	
	a11.setBounds(470, 40, 50,30);
	a12.setBounds(520, 40, 50,30);
	a13.setBounds(570, 40, 50,30);
	a14.setBounds(620, 40, 50,30);

	q2.setBounds(10, 70, 300, 40);
	a2.setBounds(420, 70, 50,30);
	
	a21.setBounds(470, 70, 50,30);
	a22.setBounds(520, 70, 50,30);
	a23.setBounds(570, 70, 50,30);
	a24.setBounds(620, 70, 50,30);

	
	q3.setBounds(10, 100, 300, 40);
	a3.setBounds(420, 100, 50,30);
	
	a31.setBounds(470, 100, 50,30);
	a32.setBounds(520, 100, 50,30);
	a33.setBounds(570, 100, 50,30);
	a34.setBounds(620, 100, 50,30);
	
	a4.setBounds(10, 130, 200, 30 );
	v1.setBounds(10, 160, 400, 70);
	v2.setBounds(10, 230, 200, 30);
	q4.setBounds(10, 250, 200, 30);
	
	a5.setBounds(425, 250, 50, 30);
	a51.setBounds(470, 250, 50,30);
	a52.setBounds(520, 250, 50,30);
	a53.setBounds(570, 250, 50,30);
	a54.setBounds(620, 250, 50,30);

	
	
	q5.setBounds(10, 290, 200, 30);
	a6.setBounds(425, 290, 50, 30);
	a61.setBounds(470, 290, 50,30);
	a62.setBounds(520, 290, 50,30);
	a63.setBounds(570, 290, 50,30);
	a64.setBounds(620, 290, 50,30);
	
	q6.setBounds(10, 330, 200, 30);
	a7.setBounds(425, 330, 50, 30);
	a71.setBounds(470, 330, 50,30);
	a72.setBounds(520, 330, 50,30);
	a73.setBounds(570, 330, 50,30);
	a74.setBounds(620, 330, 50,30);
	
	r1.setBounds(10, 400, 200, 30);
	r12.setBounds(10, 450, 400, 70);
	
	b1.setBounds(10, 550, 200, 30);
	b2.setBounds(10, 600, 200, 30);
	add(q); 
	add(q1);
	add(a1);
	add(a11);
	add(a12);
	add(a13);
	add(a14);
	
	add(q2);
	add(a2);
	add(a21);
	add(a22);
	add(a23);
	add(a24);
	
	add(q3);
	add(a3);
	add(a31);
	add(a32);
	add(a33);
	add(a34);
	
	add(a4);
	add(v1);
	add(q4);
	
	add(a5);
	add(a51);
	add(a52);
	add(a53);
	add(a54);
	add(q5);
	
	add(a6);
	add(a61);
	add(a62);
	add(a63);
	add(a64);
	
	add(q6);
	add(a7);
	add(a71);
	add(a72);
	add(a73);
	add(a74);
	
	add(v2);
	add(r1);
	add(r12);
	add(b1);
	add(b2);
	b1.addActionListener(this);
	b2.addActionListener(this);
}
	
public void actionPerformed(ActionEvent e) {
if(e.getSource() == b1) {
List<String> TopKom = new ArrayList<>();
TopKom.add("1"); TopKom.add("2"); TopKom.add("3"); TopKom.add("4"); TopKom.add("5");
 
 if(a1.isSelected()){
 System.out.println("Nota per pasterti eshte: "+ TopKom.get(0));}  
 if(a11.isSelected()){
 System.out.println("Nota per pasterti eshte: "+ TopKom.get(1));}
 if(a12.isSelected()){
 System.out.println("Nota per pasterti eshte: "+ TopKom.get(2));} 
 if(a13.isSelected()){
 System.out.println("Nota per pasterti eshte: "+ TopKom.get(3));}
 if(a14.isSelected()){
 System.out.println("Nota per pasterti eshte: "+ TopKom.get(4));}   
 
 if(a2.isSelected()){
 System.out.println("Nota per ushqim eshte: "+ TopKom.get(0));}  
 if(a21.isSelected()){
 System.out.println("Nota per ushqim  eshte: "+ TopKom.get(1));}
 if(a22.isSelected()){
 System.out.println("Nota per ushqim  eshte: "+ TopKom.get(2));} 
 if(a23.isSelected()){
 System.out.println("Nota per ushqim  eshte: "+ TopKom.get(3));}
 if(a24.isSelected()){
 System.out.println("Nota per ushqim  eshte: "+ TopKom.get(4));} 
 

 if(a3.isSelected()){
 System.out.println("Nota per inventari eshte: "+ TopKom.get(0));}  
 if(a31.isSelected()){
 System.out.println("Nota per inventari  eshte: "+ TopKom.get(1));}
 if(a32.isSelected()){
 System.out.println("Nota per inventari  eshte: "+ TopKom.get(2));} 
 if(a33.isSelected()){
 System.out.println("Nota per inventari  eshte: "+ TopKom.get(3));}
 if(a34.isSelected()){
 System.out.println("Nota per inventari  eshte: "+ TopKom.get(4));} 
 
 if(a5.isSelected()){
 System.out.println("Nota per sherbim eshte: "+ TopKom.get(0));}  
 if(a51.isSelected()){
 System.out.println("Nota per sherbim  eshte: "+ TopKom.get(1));}
 if(a52.isSelected()){
 System.out.println("Nota per sherbim  eshte: "+ TopKom.get(2));} 
 if(a53.isSelected()){
 System.out.println("Nota per sherbim  eshte: "+ TopKom.get(3));}
 if(a54.isSelected()){
 System.out.println("Nota per sherbim  eshte: "+ TopKom.get(4));} 
 
 
 if(a6.isSelected()){
 System.out.println("Nota per mikepritje eshte: "+ TopKom.get(0));}  
 if(a61.isSelected()){
 System.out.println("Nota per mikepritje  eshte: "+ TopKom.get(1));}
 if(a62.isSelected()){
 System.out.println("Nota per mikepritje  eshte: "+ TopKom.get(2));} 
 if(a63.isSelected()){
 System.out.println("Nota per mikepritje  eshte: "+ TopKom.get(3));}
 if(a64.isSelected()){
 System.out.println("Nota per mikepritje  eshte: "+ TopKom.get(4));} 
 
 if(a7.isSelected()){
 System.out.println("Nota per ndriqim  eshte: "+ TopKom.get(0));}  
 if(a71.isSelected()){
 System.out.println("Nota per ndriqim   eshte: "+ TopKom.get(1));}
 if(a72.isSelected()){
 System.out.println("Nota per ndriqim   eshte: "+ TopKom.get(2));} 
 if(a73.isSelected()){
 System.out.println("Nota per ndriqim   eshte: "+ TopKom.get(3));}
 if(a74.isSelected()){
 System.out.println("Nota per ndriqim  eshte: "+ TopKom.get(4));} 
 

JOptionPane.showMessageDialog(null, "Thank you for your feedback","Finish", JOptionPane.YES_NO_OPTION);
			
		}
		else if
			(e.getSource()== b2) {
				System.exit(0);
			
			}
}
}