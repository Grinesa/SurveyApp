import java.util.ArrayList;
import java.util.List;
public class SurveyApp1
{
public static void main(String[] args){
String a_btnNames[] = {"clearBtn", "plusMinusBtn", "divBtn", "multiBtn", "sevenBtn", "eightBtn", "nineBtn", "subBtn", "fourBtn", "fiveBtn", "sixBtn",                               "addBtn", "oneBtn", "twoBtn", "threeBtn", "equalsBtn", "zeroBtn", "decimalBtn"};
        // array String whit all button characters
        String a_btnCharts[] = {"C", "+/-", "/", "*", "7", "8", "9", "-", "4", "5", "6", "+", "1", "2", "3", "=", "0", "."};

        for(int i = 0; i < buttons.length; i++)
        {
            // make new button name 
            buttons[i]  = new JButton(a_btnNames[i]);
            // add button to panel
            panel.add(new JButton(a_btnCharts[i]));
            //System.out.println(buttons[i]);
        }
}
}
